import script2
import time

def myloop(): 
        while True: 
                script2.dabber() 
                time.sleep(5) 

myloop()


