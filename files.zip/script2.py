def dabber():
	f= open("dabbi","a+")
	for i in range(5):
		f.write("dab\n")
	f.close()
